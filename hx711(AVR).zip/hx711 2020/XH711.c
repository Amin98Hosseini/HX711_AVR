
#include <mega32a.h>
#include <stdio.h>
#include <stdlib.h>
#include <delay.h>
#include <lcd.h>
#asm

.equ __lcd_port=0x1B     //PORTA

#endasm

#define DOUT  PINB.0        //Rx
#define SCK   PORTB.1      //Tx



void Delay(void)
{
    #asm("nop")      // Delay asm
       #asm("nop")
}
//_______________________hx711_____________gain128__________________________________________

unsigned long HX711_Read(void)   
{
    unsigned long count; 
    unsigned char i; 
      
      DOUT=1; 
         Delay();
             SCK=0; 
                count=0;
                   while(DOUT); 
      for(i=0;i<24;i++)  
        { 
            SCK=1; 
               count=count<<1; 
                  SCK=0; 
                     if(DOUT)
                         count++; 
        }     
        
       SCK=1; 
          count=count & 0xfff000;
              Delay();
                   SCK=0;  
                       return(count);
}
//___________________________________________________________________________________

void main(void)
{

char buffer[10];      
DDRB = 1 << DDB1 ; 
    
lcd_init(16);    
lcd_clear();    
 
    
   
    
    

while(1){
         
     ltoa(HX711_Read()/1000 , buffer);   // LONG Conversion TO char                                                                                                                                                                                                                                                                                                                                                                                                             
           
             lcd_puts(buffer);
                  delay_ms(650);
                      lcd_clear();
            
 }    
          
}


  
       
           


